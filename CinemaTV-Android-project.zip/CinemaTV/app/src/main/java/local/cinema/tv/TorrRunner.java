package local.cinema.tv;

import android.content.Context;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.Map;

/**
 * Запускает встроенный TorrServer (файл libtorrserver.so из jniLibs — это обычный исполняемый файл Android)
 * на 127.0.0.1:8090 и перезапускает его, если он остановился.
 */
final class TorrRunner {

    private static final int PORT = 8090;
    private static Thread watcher;
    private static Process proc;
    private static volatile boolean stop;
    private static volatile String state = "idle";

    private TorrRunner() {}

    static synchronized void start(final Context ctx) {
        if (watcher != null && watcher.isAlive()) return;
        stop = false;
        final File bin = new File(ctx.getApplicationInfo().nativeLibraryDir, "libtorrserver.so");
        if (!bin.exists()) {
            state = "missing";
            return;
        }
        final File dir = new File(ctx.getFilesDir(), "torrserver");
        dir.mkdirs();
        watcher = new Thread(new Runnable() {
            @Override
            public void run() {
                int fails = 0;
                while (!stop) {
                    long t0 = System.currentTimeMillis();
                    try {
                        ProcessBuilder pb = new ProcessBuilder(bin.getAbsolutePath(), "-p", String.valueOf(PORT), "-d", dir.getAbsolutePath());
                        pb.directory(dir);
                        pb.redirectErrorStream(true);
                        Map<String, String> env = pb.environment();
                        env.put("HOME", dir.getAbsolutePath());
                        env.put("TMPDIR", ctx.getCacheDir().getAbsolutePath());
                        pb.redirectOutput(new File(dir, "ts.log"));
                        Process p = pb.start();
                        synchronized (TorrRunner.class) { proc = p; }
                        state = "running";
                        p.waitFor();
                    } catch (Throwable e) {
                        state = "dead";
                    }
                    if (stop) break;
                    state = "dead";
                    fails = (System.currentTimeMillis() - t0 > 30000) ? 0 : fails + 1;
                    if (fails > 8) break;
                    try { Thread.sleep(2000); } catch (InterruptedException ie) { break; }
                }
            }
        }, "torrserver-watch");
        watcher.setDaemon(true);
        watcher.start();
    }

    static synchronized void restart(Context ctx) {
        stopNow();
        try { Thread.sleep(800); } catch (InterruptedException e) { /* ignore */ }
        start(ctx);
    }

    static synchronized void stopNow() {
        stop = true;
        if (proc != null) { try { proc.destroy(); } catch (Throwable e) { /* ignore */ } proc = null; }
        if (watcher != null) { watcher.interrupt(); watcher = null; }
    }

    static String status() {
        return state;
    }
}
