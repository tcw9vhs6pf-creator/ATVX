package local.cinema.tv;

import android.app.Activity;
import android.graphics.Color;
import android.net.http.SslError;
import android.os.Build;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.SslErrorHandler;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

/**
 * Оболочка Cinema для Android TV / приставок: полноэкранный WebView с локальной копией приложения
 * (assets/index.html → app.html). Пульт: стрелки и OK WebView отдаёт странице сам, «Назад», медиаклавиши,
 * цветные кнопки и каналы пересылаются в страницу как клавиатурные события (те же коды, что у Samsung).
 */
public class MainActivity extends Activity {

    private WebView web;
    private FrameLayout root;
    private View customView;
    private WebChromeClient.CustomViewCallback customCb;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        TorrRunner.start(getApplicationContext());
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.BLACK));

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        web = new WebView(this);
        web.setBackgroundColor(Color.BLACK);
        root.addView(web, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(root);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        // запросы со страницы к TMDB, Worker и источникам идут без ограничений CORS (как в приложении для Samsung)
        s.setAllowFileAccessFromFileURLs(true);
        s.setAllowUniversalAccessFromFileURLs(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setSupportMultipleWindows(false);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setUserAgentString(s.getUserAgentString() + " Android TV CinemaApp/2.9.68 CinemaAndroid");

        web.addJavascriptInterface(new Bridge(), "CinemaApp");
        web.setFocusable(true);
        web.setFocusableInTouchMode(true);
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                return false;
            }

            @Override
            public void onReceivedSslError(WebView v, SslErrorHandler h, SslError e) {
                h.cancel();
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onShowCustomView(View v, CustomViewCallback cb) {
                if (customView != null) {
                    cb.onCustomViewHidden();
                    return;
                }
                customView = v;
                customCb = cb;
                root.addView(v, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
                web.setVisibility(View.GONE);
            }

            @Override
            public void onHideCustomView() {
                hideCustom();
            }

            @Override
            public void onPermissionRequest(PermissionRequest r) {
                r.deny();
            }
        });

        if (b != null) {
            web.restoreState(b);
        } else {
            web.loadUrl("file:///android_asset/index.html");
        }
        goImmersive();
        web.requestFocus();
    }

    private void hideCustom() {
        if (customView == null) return;
        root.removeView(customView);
        customView = null;
        web.setVisibility(View.VISIBLE);
        if (customCb != null) {
            customCb.onCustomViewHidden();
            customCb = null;
        }
        web.requestFocus();
    }

    private void goImmersive() {
        View d = getWindow().getDecorView();
        d.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    @Override
    public void onWindowFocusChanged(boolean f) {
        super.onWindowFocusChanged(f);
        if (f) goImmersive();
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        if (web != null) web.saveState(out);
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (web != null) web.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (web != null) web.onResume();
    }

    @Override
    protected void onDestroy() {
        if (web != null) {
            web.destroy();
            web = null;
        }
        super.onDestroy();
    }

    /** Отправляет на страницу нажатие клавиши (страница слушает keydown и смотрит keyCode / key). */
    private void sendKey(String key, int code) {
        if (web == null) return;
        String js = "(function(){var e=new KeyboardEvent('keydown',{key:'" + key + "',bubbles:true,cancelable:true});"
                + "try{Object.defineProperty(e,'keyCode',{get:function(){return " + code + "}});"
                + "Object.defineProperty(e,'which',{get:function(){return " + code + "}})}catch(x){}"
                + "(document.activeElement||document).dispatchEvent(e)})()";
        web.evaluateJavascript(js, null);
    }

    @Override
    public boolean onKeyDown(int k, KeyEvent ev) {
        if (customView != null && k == KeyEvent.KEYCODE_BACK) {
            hideCustom();
            return true;
        }
        if (ev.getRepeatCount() == 0) {
            switch (k) {
                case KeyEvent.KEYCODE_BACK:
                case KeyEvent.KEYCODE_ESCAPE:
                    sendKey("GoBack", 10009);
                    return true;
                case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE:
                    sendKey("MediaPlayPause", 179);
                    return true;
                case KeyEvent.KEYCODE_MEDIA_PLAY:
                    sendKey("MediaPlay", 415);
                    return true;
                case KeyEvent.KEYCODE_MEDIA_PAUSE:
                    sendKey("MediaPause", 19);
                    return true;
                case KeyEvent.KEYCODE_MEDIA_STOP:
                    sendKey("MediaStop", 413);
                    return true;
                case KeyEvent.KEYCODE_MEDIA_FAST_FORWARD:
                case KeyEvent.KEYCODE_MEDIA_NEXT:
                    sendKey("MediaFastForward", 417);
                    return true;
                case KeyEvent.KEYCODE_MEDIA_REWIND:
                case KeyEvent.KEYCODE_MEDIA_PREVIOUS:
                    sendKey("MediaRewind", 412);
                    return true;
                case KeyEvent.KEYCODE_CHANNEL_UP:
                    sendKey("ChannelUp", 427);
                    return true;
                case KeyEvent.KEYCODE_CHANNEL_DOWN:
                    sendKey("ChannelDown", 428);
                    return true;
                case KeyEvent.KEYCODE_PROG_RED:
                    sendKey("ColorF0Red", 403);
                    return true;
                case KeyEvent.KEYCODE_PROG_GREEN:
                    sendKey("ColorF1Green", 404);
                    return true;
                case KeyEvent.KEYCODE_PROG_YELLOW:
                    sendKey("ColorF2Yellow", 405);
                    return true;
                case KeyEvent.KEYCODE_PROG_BLUE:
                    sendKey("ColorF3Blue", 406);
                    return true;
                default:
                    break;
            }
        } else if (k == KeyEvent.KEYCODE_BACK) {
            return true;
        }
        return super.onKeyDown(k, ev);
    }

    /** Мост для страницы: window.CinemaApp.exit() закрывает приложение (двойное «Назад» на главной). */
    private class Bridge {
        @JavascriptInterface
        public void exit() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    finish();
                }
            });
        }

        @JavascriptInterface
        public String tsStatus() {
            return TorrRunner.status();
        }

        @JavascriptInterface
        public void tsRestart() {
            TorrRunner.restart(getApplicationContext());
        }

        @JavascriptInterface
        public String platform() {
            return "android-tv";
        }
    }
}
