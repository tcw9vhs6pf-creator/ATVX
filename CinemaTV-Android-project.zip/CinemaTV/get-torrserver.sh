#!/bin/sh
# Скачивает TorrServer для Android в проект (для сборки в Android Studio). Запуск: sh get-torrserver.sh
set -e
cd "$(dirname "$0")"
mkdir -p app/src/main/jniLibs/arm64-v8a app/src/main/jniLibs/armeabi-v7a
curl -fL https://github.com/YouROK/TorrServer/releases/latest/download/TorrServer-android-arm64 -o app/src/main/jniLibs/arm64-v8a/libtorrserver.so
curl -fL https://github.com/YouROK/TorrServer/releases/latest/download/TorrServer-android-arm7 -o app/src/main/jniLibs/armeabi-v7a/libtorrserver.so
echo Готово
