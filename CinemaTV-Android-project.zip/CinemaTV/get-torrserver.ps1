# Скачивает TorrServer для Android в проект (для сборки в Android Studio). Запуск: правая кнопка → Выполнить с помощью PowerShell
$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
$a = 'app\src\main\jniLibs\arm64-v8a'; $b = 'app\src\main\jniLibs\armeabi-v7a'
New-Item -ItemType Directory -Force $a, $b | Out-Null
$ProgressPreference = 'SilentlyContinue'
Invoke-WebRequest 'https://github.com/YouROK/TorrServer/releases/latest/download/TorrServer-android-arm64' -OutFile "$a\libtorrserver.so" -UseBasicParsing
Invoke-WebRequest 'https://github.com/YouROK/TorrServer/releases/latest/download/TorrServer-android-arm7' -OutFile "$b\libtorrserver.so" -UseBasicParsing
Write-Host 'Готово'
